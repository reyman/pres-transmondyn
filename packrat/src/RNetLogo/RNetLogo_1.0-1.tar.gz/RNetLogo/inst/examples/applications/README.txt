The application examples are described in the Tutorial. Here you can find the complete R source code of the examples.
