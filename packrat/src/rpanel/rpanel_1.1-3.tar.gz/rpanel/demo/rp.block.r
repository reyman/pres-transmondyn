panel <- rp.control(panelname="panel")
rp.block(panel)