rp.messagebox("This is a messagebox!")
rp.messagebox("The user can also set the title.", "Multiple messages are joined together.", title="Important!")
